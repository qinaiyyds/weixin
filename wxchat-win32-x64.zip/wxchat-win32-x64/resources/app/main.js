const { app, BrowserWindow, Menu } = require('electron')

// 热加载
// const reloader = require('electron-reloader')
// reloader(module)

// 监听初始化完成得到生命周期
app.on('ready', () => {
    const mainWindow = new BrowserWindow({
        width: 1360,
        height: 900,
        show: false,
        // frame: false, // 无边框窗口（自定义菜单栏会隐藏）
    })
    // 加载文件
    mainWindow.loadFile("./src/index.html")
    // mainWindow.loadURL("https://www.baidu.com/")

    // 窗口默认最大化
    mainWindow.maximize()
    mainWindow.show()

    // 引入顶部菜单栏
    require("./menu.js")
})