const { BrowserWindow, Menu } = require('electron')
// 顶部菜单栏
const template = [
    {
        label: "文件"
    },
    {
        label: "编辑"
    },
    {
        label: "选择"
    },
    {
        label: "查看"
    },
    {
        label: "帮助"
    },
    {
        label: "关于我们",
        submenu: [
            {
                label: "关注作者抖音号：peng071121",
            },
            {
                label: "检查更新",
                // 添加事件
                // click () {
                //     new BrowserWindow({
                //         width: 500,
                //         height: 500
                //     })
                // }
            },
        ]
    },
    {
        label: "刷新",
        role: "reload"
    }
]
// 编译模板
const menu = Menu.buildFromTemplate(template)
// 注册设置菜单
Menu.setApplicationMenu(menu)